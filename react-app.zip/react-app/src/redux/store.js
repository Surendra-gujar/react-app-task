import { createStore, applyMiddleware, combineReducers } from "redux";
import { thunk } from "redux-thunk";
import reducers from "../redux/reducers";

const rootReducer = combineReducers({
  posts: reducers,
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
